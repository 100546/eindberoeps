// Scroll naar een bepaalde categorie
function scrollToCategory(categoryId) {
    const category = document.getElementById(categoryId);
    if (category) {
        category.scrollIntoView({ behavior: 'smooth' });
    }
}

// Wacht tot de DOM geladen is
window.addEventListener('DOMContentLoaded', () => {
    // Animatie vertraging instellen voor scroll-iconen
    const scrollIcons = document.querySelectorAll('.scroll-icon span');
    scrollIcons.forEach((icon, index) => {
        icon.style.animationDelay = `${index * 0.2}s`;
    });

    // Elementen selecteren voor de bied-modal
    const modal = document.getElementById('bid-modal');
    const closeModal = modal.querySelector('.close');
    const bidForm = document.getElementById('bid-form');
    const productIdInput = document.getElementById('product-id');
    const bidAmountInput = document.getElementById('bid-amount');

    let currentProductId;

    // Functie om bied-modal te openen
    window.openBidModal = (productId) => {
        currentProductId = productId;
        productIdInput.value = productId;
        modal.style.display = 'block';
    };

    // Sluit de modal bij klikken op de sluitknop
    closeModal.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    // Verwerk het biedingsformulier bij indienen
    bidForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const bidAmount = parseFloat(bidAmountInput.value);

        // Bieding verzenden via AJAX
        fetch('submit_bid.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `product_id=${currentProductId}&bid_amount=${bidAmount}`
        })
            .then(response => response.json())
            .then(data => {
                // Update het hoogste bod weergegeven voor het product
                const productElement = document.querySelector(`.product[data-id='${currentProductId}']`);
                const highestBidElement = productElement.querySelector('.highest-bid');
                highestBidElement.textContent = data.highest_bid.toFixed(2);

                // Sluit de modal
                modal.style.display = 'none';
            })
            .catch(error => console.error('Error:', error));
    });

    // Sluit de modal bij klikken buiten de modal
    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
});
