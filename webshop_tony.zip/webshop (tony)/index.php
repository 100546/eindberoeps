<?php
// Maak de verbinding met de SQLite database
$dsn = "sqlite:webshop.db"; // Vervang dit door het pad naar je SQLite database
try {
    $pdo = new PDO($dsn);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Functie om hoogste bod op te halen
    function getHighestBid($pdo, $product_id) {
        $sql = "SELECT MAX(bid_amount) AS highest_bid FROM bids WHERE product_id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$product_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['highest_bid'] ?: 0; // Geef 0 terug als er geen bod is gevonden
    }

    // Haal de producten op
    $stmt = $pdo->query("SELECT * FROM products");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Groepeer producten per categorie en voeg hoogste bod toe
    $grouped_products = [];
    foreach ($products as $product) {
        $category = $product['category']; // Stel dat 'category' het veld in de database is dat de categorie aanduidt
        if (!isset($grouped_products[$category])) {
            $grouped_products[$category] = [];
        }
        $product['highest_bid'] = getHighestBid($pdo, $product['id']); // Voeg hoogste bod toe aan product
        $grouped_products[$category][] = $product;
    }

    // Verwerk het biedingsformulier wanneer het wordt ingediend
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_bid'])) {
        // Controleer of alle vereiste velden zijn ingevuld
        if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['bid_amount']) && isset($_POST['product_id'])) {
            $name = htmlspecialchars($_POST['name']);
            $email = htmlspecialchars($_POST['email']);
            $bid_amount = $_POST['bid_amount'];
            $product_id = $_POST['product_id'];

            // Controleer of er al een bod bestaat voor dit product
            $existingBid = getHighestBid($pdo, $product_id);

            // Vergelijk het huidige bod met het nieuwe bod
            if ($bid_amount > $existingBid) {
                try {
                    // Voorbereid de SQL-instructie om het bod in de database in te voegen
                    $sql = "INSERT INTO bids (product_id, name, email, bid_amount, bid_time) VALUES (?, ?, ?, ?, datetime('now'))";

                    // Bereid de statement voor
                    $stmt = $pdo->prepare($sql);

                    // Voer de statement uit met de gegevens van het formulier
                    $stmt->execute([$product_id, $name, $email, $bid_amount]);
                } catch (PDOException $e) {
                    echo "Fout bij het invoegen van bod: " . $e->getMessage();
                }
            } else {
                echo "Je bod moet hoger zijn dan het huidige hoogste bod.";
            }
        } else {
            echo "Alle velden moeten worden ingevuld.";
        }
    }

} catch (PDOException $e) {
    echo "Verbinding mislukt: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,800;1,800&family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Webshop Design</title>
</head>
<body>
<div class="hero">
    <div class="hero-content">
        <img src="#" alt="logo">
        <p>....................</p>
    </div>
</div>
        <<div class="product-container1">
            <div class="product1">
                <img src="#" alt="Product Image">
                <h3>Product Name</h3>
                <p>Description: ...</p>
                <button class="bid-button1">
                    Bid Now <i class="fas fa-arrow-right"></i>
                </button>
            </div>

            <div class="product1">
                <img src="#" alt="Product Image">
                <h3>Product Name</h3>
                <p>Description: ...</p>
                <button class="bid-button1">
                    Bid Now <i class="fas fa-arrow-right"></i>
                </button>
            </div>

            <div class="product1">
                <img src="#" alt="Product Image">
                <h3>Product Name</h3>
                <p>Description: ...</p>
                <button class="bid-button1">
                    Bid Now <i class="fas fa-arrow-right"></i>
                </button>
            </div>

            <div class="product1">
                <img src="#" alt="Product Image">
                <h3>Product Name</h3>
                <p>Description: ...</p>
                <button class="bid-button1">
                    Bid Now <i class="fas fa-arrow-right"></i>
                </button>
            </div>
        </div>

<div class="banner">
    <img src="media/banner.webp" alt="Banner Image">
</div>

<div id="products" class="products">
    <div class="begin-text"><h2>Marketplace</h2></div>
    <div class="category-buttons">
        <button onclick="scrollToCategory('vehicle')">Vehicle</button>
        <button onclick="scrollToCategory('jets')">Jets</button>
        <button onclick="scrollToCategory('watches')">Watches</button>
    </div>
    <div class="featured-bids">
        <div class="featured-products">
            <?php foreach ($grouped_products as $category => $products): ?>
                <div id="<?php echo strtolower($category); ?>" class="category-section">
                    <h2><?php echo htmlspecialchars($category); ?></h2>
                    <div class="featured-products">
                        <?php foreach ($products as $bids): ?>
                            <div class="product">
                                <img src="<?php echo htmlspecialchars($bids['image_url']); ?>" alt="Product Image">
                                <h3><?php echo htmlspecialchars($bids['name']); ?></h3>
                                <p><?php echo htmlspecialchars($bids['description']); ?></p>
                                <p>Highest Bid: €<?php echo htmlspecialchars(number_format($bids['highest_bid'], 2)); ?></p>
                                <button class="bid-button" onclick="openBidModal(<?php echo $bids['id']; ?>)">
                                    Bid Now <i class="fas fa-arrow-right"></i>
                                </button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div id="bid-modal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Auction</h2>
            <div class="product-details">
                <div class="product-image">
                    <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="Product Image">
                </div>
                <div class="product-info">
                    <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p><?php echo htmlspecialchars($product['description']); ?></p>
                    <p>Highest Bid: <span id="highest-bid">€<?php // echo htmlspecialchars($bid_amount); ?></span></p>
                </div>
            </div>
            <form id="bid-form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" id="product-id" name="product_id" value="<?php echo $product['id']; ?>">
                <label for="name">Naam:</label>
                <input type="text" id="name" name="name" required>
                <label for="email">E-mail:</label>
                <input type="email" id="email" name="email" required>
                <label for="bid-amount">Bodbedrag:</label>
                <input type="number" id="bid-amount" name="bid_amount" step="0.01" min="0" required>
                <button type="submit" class="submit-button"><span>Plaats bod</span></button>
            </form>
        </div>
    </div>


    <script>
        // JavaScript functies voor modaal venster en biedingen
        function openBidModal(product_id) {
            // Vul de modal met productgegevens
            var modal = document.getElementById("bid-modal");
            modal.style.display = "block";

            // Haal productgegevens op
            var products = <?php echo json_encode($products); ?>;
            var selectedProduct = products.find(item => item.id == product_id);

            // Vul de modal met gegevens van het product
            document.getElementById("modal-product-name").textContent = selectedProduct.name;
            document.getElementById("modal-product-image").src = selectedProduct.image_url;
            document.getElementById("modal-product-description").textContent = selectedProduct.description;
            document.getElementById("modal-highest-bid").textContent = "€" + parseFloat(selectedProduct.highest_bid).toFixed(2);

            // Vul het verborgen veld in het biedingsformulier in
            document.getElementById("product_id").value = product_id;
        }

        // Sluit modaal venster bij het klikken op X
        var closeBtn = document.getElementsByClassName("close")[0];
        closeBtn.onclick = function() {
            var modal = document.getElementById("bid-modal");
            modal.style.display = "none";
        };

        // Sluit modaal venster bij klikken buiten het modaal venster
        window.onclick = function(event) {
            var modal = document.getElementById("bid-modal");
            if (event.target == modal) {
                modal.style.display = "none";
            }
        };

        // Scroll naar de categorie sectie
        function scrollToCategory(category) {
            var categorySection = document.getElementById(category.toLowerCase());
            if (categorySection) {
                categorySection.scrollIntoView({ behavior: 'smooth' });
            }
        }
    </script>
</body>
</html>
