<?php
// Connect to SQLite database (creates the database file if it doesn't exist)
$db = new SQLite3('webshop.db');

// Create products table if it doesn't exist
$db->exec("CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    image_url TEXT NOT NULL
)");

// Insert sample data into the products table
$products = [
    // Watches
    ['watches', 'Rolex Day-Date 40', 'Oyster, 40 mm, Platina', 'media-shop/rolex-1.avif'],
    ['watches', 'Rolex Day-Date 31', 'Oyster, 36 mm, Bronze', 'media-shop/rolex-2.jpg'],
    ['watches', 'Rolex Day-Date 36', 'Oyster, 36 mm, Everose-goud en diamanten', 'media-shop/rolex-3.webp'],
    ['watches', 'Rolex Day-Date 32', 'Oyster, 40mm, Silver en diamanten', 'media-shop/rolex-4.webp'],

    // Boats
    ['boats', 'Luxury Yacht 1', 'Beschrijving van Luxury Yacht 1', 'media-shop/yacht-1.jpg'],
    ['boats', 'Luxury Yacht 2', 'Beschrijving van Luxury Yacht 2', 'media-shop/yacht-2.jpg'],
    ['boats', 'Luxury Yacht 3', 'Beschrijving van Luxury Yacht 3', 'media-shop/yacht-3.jpg'],
    ['boats', 'Luxury Yacht 4', 'Beschrijving van Luxury Yacht 4', 'media-shop/yacht-4.jpg'],

    // Jets
    ['jets', 'Private Jet 1', 'Beschrijving van Private Jet 1', 'media-shop/jet-1.jpg'],
    ['jets', 'Private Jet 2', 'Beschrijving van Private Jet 2', 'media-shop/jet-2.jpg'],
    ['jets', 'Private Jet 3', 'Beschrijving van Private Jet 3', 'media-shop/jet-3.jpg'],
    ['jets', 'Private Jet 4', 'Beschrijving van Private Jet 4', 'media-shop/jet-4.jpg'],

    // Champagne
    ['champagne', 'Champagne Brand 1', 'Beschrijving van Champagne Brand 1', 'media-shop/champagne-1.jpg'],
    ['champagne', 'Champagne Brand 2', 'Beschrijving van Champagne Brand 2', 'media-shop/champagne-2.jpg'],
    ['champagne', 'Champagne Brand 3', 'Beschrijving van Champagne Brand 3', 'media-shop/champagne-3.jpg'],
    ['champagne', 'Champagne Brand 4', 'Beschrijving van Champagne Brand 4', 'media-shop/champagne-4.jpg'],

    // Houses
    ['houses', 'Luxury House 1', 'Beschrijving van Luxury House 1', 'media-shop/house-1.jpg'],
    ['houses', 'Luxury House 2', 'Beschrijving van Luxury House 2', 'media-shop/house-2.jpg'],
    ['houses', 'Luxury House 3', 'Beschrijving van Luxury House 3', 'media-shop/house-3.jpg'],
    ['houses', 'Luxury House 4', 'Beschrijving van Luxury House 4', 'media-shop/house-4.jpg'],
];

// Prepare the insert statement
$stmt = $db->prepare("INSERT INTO products (category, name, description, image_url) VALUES (:category, :name, :description, :image_url)");

// Insert each product into the database
foreach ($products as $product) {
    $stmt->bindValue(':category', $product[0], SQLITE3_TEXT);
    $stmt->bindValue(':name', $product[1], SQLITE3_TEXT);
    $stmt->bindValue(':description', $product[2], SQLITE3_TEXT);
    $stmt->bindValue(':image_url', $product[3], SQLITE3_TEXT);
    $stmt->execute();
}

echo "Database setup completed.";
?>
