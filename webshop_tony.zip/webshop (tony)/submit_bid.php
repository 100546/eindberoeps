<?php
$db = new SQLite3('webshop.db');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productId = intval($_POST['product_id']);
    $bidAmount = floatval($_POST['bid_amount']);

    // Update the highest bid for the product if the new bid is higher
    $stmt = $db->prepare('UPDATE products SET highest_bid = :bid WHERE id = :id AND highest_bid < :bid');
    $stmt->bindValue(':bid', $bidAmount, SQLITE3_FLOAT);
    $stmt->bindValue(':id', $productId, SQLITE3_INTEGER);
    $stmt->execute();

    // Get the updated highest bid
    $stmt = $db->prepare('SELECT highest_bid FROM products WHERE id = :id');
    $stmt->bindValue(':id', $productId, SQLITE3_INTEGER);
    $result = $stmt->execute();
    $row = $result->fetchArray(SQLITE3_ASSOC);

    echo json_encode(['highest_bid' => $row['highest_bid']]);
}
?>
